package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {
	
	boolean save(Product p);

	List<Product> findall();


	Product findById(int pid);

	List<Product> findByPrice(double pr);

	List<Product> findByName(String pnm);

	List<Product> sortid();

	

	
}

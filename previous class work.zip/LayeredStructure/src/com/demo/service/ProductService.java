package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	boolean addnewProduct();

	List<Product> displayall();

	Product searchById(int pid);

	List<Product> searchByPrice(double pr);

	List<Product> searchByName(String pnm);

	List<Product> sortById(int pid);

	int deleteId();

	

	

	

}

package com.demo.test;
import com.demo.beans.Product;
import com.demo.service.*;

import java.util.List;
import java.util.Scanner;

public class TestProduct {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		ProductService pservice = new ProductServiceImpl();
		int choice =0;
		
		do {
			System.out.println("1.Add new Product \n2.Display \n3.Display By Id");
			System.out.println("4.Display by Name \n5.Display By Price \n6. Display Sorted by Id");
			System.out.println("7.Display Sorted by Name \n8.Delete By Id \n9.Modify Product");
			System.out.println("10.Exit/Close");
			choice =sc.nextInt();
			switch(choice)
			{
			case 1:
				boolean status = pservice.addnewProduct();
				if(status) {
					System.out.println("Added Successfully");
				}
				else {
					System.out.println("Error Occurred");
				}
				break;
				
			case 2:
				List<Product> plist = pservice.displayall();
				plist.stream().forEach(ob->System.out.println(ob));
				
				break;
				
			case 3:
				System.out.println("Enter Id to be Searched");
				int pid=sc.nextInt();
				Product p = pservice.searchById(pid);
				if(p!=null)
				{
					System.out.println(p);
				}
				else
				{
					System.out.println("Not Found");
				}
				break;
			case 4:
				System.out.println("Enter namae to be searched");
				String pnm = sc.next();
				List<Product> pn= pservice.searchByName(pnm);
				plist = pservice.searchByName(pnm);
				plist.stream().forEach(ob->System.out.println(ob));
				break;
			case 5:
				System.out.println("Enter Price");
				  float price = sc.nextFloat();
				  plist = pservice.searchByPrice(price); 
				  plist.stream().forEach(ob->System.out.println(ob));
				break;
				
			case 6:
				System.out.println("Enter id number to sort");
				plist = pservice.sortById(spid);
				plist.stream().forEach(ob ->System.out.println(ob));
				break;
				
			case 8:
				System.out.println("Enter Product id to be Removed");
				int did = pservice.deleteId(); 
			case 10:
				
				sc.close();
				System.out.println("Thank you for Visiting!!!");
				break;
			default :
				System.out.println("Invalid Choice");
				break;
			}
		} while(choice !=10);
		
	}

}

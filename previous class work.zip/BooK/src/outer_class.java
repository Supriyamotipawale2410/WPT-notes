
public class outer_class 
{

	private int x;
	public class InnerClass
		{
		public void method2() {
			System.out.println("in method2");
		}
	}

}

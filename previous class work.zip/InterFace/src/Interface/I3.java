package Interface;

public interface I3 {

}

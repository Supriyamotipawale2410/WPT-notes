package Interface;

public interface I5 
{
	void m51();
	void m52();
}

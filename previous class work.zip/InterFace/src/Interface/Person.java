package Interface;

public class Person {

}

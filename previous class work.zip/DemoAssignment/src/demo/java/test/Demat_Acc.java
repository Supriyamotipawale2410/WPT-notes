package demo.java.test;

public class Demat_Acc extends Account {
		private double commission;
		private double intrest;
		private int pin = 1234;

		public Demat_Acc() {
			super();
			
		}

		public Demat_Acc(int id, String name, double balance,double commission) {
			super(id, name, balance);
			
			this.commission=commission;
			this.intrest= balance - 0.9*balance;
		}

		public double getCommission() {
			return commission;
		}

		public void setCommission(double commission) {
			this.commission = commission;
		}
		
		public double calcintrest()
		{
			return intrest;
		}

		@Override
		public String toString() {
			return "Demat_Acc [commission=" + commission + "]";
		}
		public void validatePin(int pin) {
			this.pin = pin;
			System.out.println("Pin correct");
		}
		
		
		
}

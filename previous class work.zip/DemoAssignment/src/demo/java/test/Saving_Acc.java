package demo.java.test;

public class Saving_Acc extends Account implements Atm1 {
	private int checqueno;
	private double intrest;

	public Saving_Acc() {
		super();
	}

	public Saving_Acc(int id, String name, double balance,int checqueno) {
		
		
		this.checqueno=checqueno;
		this.intrest= 0.2*balance;
	}

	public int getChecqueno() {
		return checqueno;
	}

	public void setChecqueno(int checqueno) {
		this.checqueno = checqueno;
	}

		public double calcintrest()
		{
			return intrest;
		}
	@Override
	public String toString() {
		return "Saving_Acc [checqueno=" + checqueno + "]";
	}
	
	
	
	
	
}

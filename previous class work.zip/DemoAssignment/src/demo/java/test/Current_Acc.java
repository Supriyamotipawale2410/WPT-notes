package demo.java.test;

public class Current_Acc extends Account implements Atm1{
		
	private int NoOfTransaction;
	private double intrest;
	public Current_Acc() {
		super();
	}
	public Current_Acc(int id, String name, double balance,int NoOfTransaction) {
		super(id, name, balance);
		this.NoOfTransaction=NoOfTransaction;
		this.intrest= 0.5*balance;
	}
	public int getNoOfTransaction() {
		return NoOfTransaction;
	}
	public void setNoOfTransaction(int noOfTransaction) {
		NoOfTransaction = noOfTransaction;
	}
	
	
	public CheckBal()
	{
		
	}
	

	@Override
	public String toString() {
		return "Current_Acc [NoOfTransaction=" + NoOfTransaction + ", intrest=" + intrest + "]";
	}
	
		
	
	@Override
	public int validatePin() {
		
		return 0;
	}
	@Override
	public int CheckBal() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void validatePin(int pin) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}

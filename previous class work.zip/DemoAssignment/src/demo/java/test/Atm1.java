package demo.java.test;

public interface Atm1 {
	void validatePin (int pin);
	int CheckBal();
}

package person;

public class Test_Person {

	public static void main(String[] args) {
		System.out.println("PERSON");

	}

}

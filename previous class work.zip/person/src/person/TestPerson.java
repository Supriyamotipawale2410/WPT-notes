package person;
import java.util.Date;

public class TestPerson {

	public static void main(String[] args) {
		Person p = new Person(1, "ram","555",new Date());
		System.out.println(p);
//		Person p1 = new Person();
//		System.out.println(p1);
		
//		it will show error because our 
//		tosting function contains date and we are not passing that
//		we have to comment dateformate and d than it will run 
		System.out.println(p.getMob());
		
		Person p2=new Person(5, "Rajan","6666",new Date());
		System.out.println(p2);

	}

}


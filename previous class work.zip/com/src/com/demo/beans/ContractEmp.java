package com.demo.beans;

public class ContractEmp extends employee 
{
	private double hour;
	private double charges;
	
	public ContractEmp()
	{
		super();
	}
	
	public ContractEmp(int id, String name, String mob,String dept, String desgn,double hour, double charges) 
	{
		super(id,name,mob,dept,desgn);
		this.hour = hour;
		this.charges = charges;
	}

	
	public double getHour()
	{
		return hour;
	}
	public void setHour(double hour)
	{
		this.hour = hour;
	}
	public double getCharges() 
	{
		return charges;
	}
	public void setCharges(double charges)
	{
		this.charges = charges;
	}
	
	@Override
	public double calsal()
	{
		return hour*charges;
	}
	
	@Override
	public String toString() {
		return "ContractEmp [hour=" + hour + ", charges=" + charges + "]";
	}


}

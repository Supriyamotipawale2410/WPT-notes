package com.demo.beans;

public class person {
	private int id;
	private String name;
	private String mob;
	public person() 
	{
		System.out.println("in person default constructor");
	}
	public person(int id, String name, String mob) 
	{
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	@Override
	public String toString() {
		return "person [id=" + id + ", name=" + name + ", mob=" + mob + "]";
	}
	

}

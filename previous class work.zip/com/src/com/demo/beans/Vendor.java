package com.demo.beans;

public class Vendor extends employee
{
	private double amt;
	private int no_of_emp;
	public Vendor() 
	{
		
	}
	public Vendor(int id, String name, String mob,String dept, String desgn,double amt, int no_of_emp)
	{
		super(id,name,mob,dept,desgn);
		this.amt = amt;
		this.no_of_emp = no_of_emp;
	}
	public double getAmt() 
	{
		return amt;
	}
	public void setAmt(double amt) 
	{
		this.amt = amt;
	}
	public int getNo_of_emp()
	{
		return no_of_emp;
	}
	public void setNo_of_emp(int no_of_emp) 
	{
		this.no_of_emp = no_of_emp;
	}
	public double calsal()
	{
		return amt*no_of_emp;
	}
	@Override
	public String toString() {
		return super.toString() + "Vendor [amt=" + amt + ", no_of_emp=" + no_of_emp + "]";
	}
	

}

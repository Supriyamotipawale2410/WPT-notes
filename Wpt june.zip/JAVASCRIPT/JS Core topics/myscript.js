 /* program to define external function */
 function fun1()
 {
	document.write("hi, i am fun1")
 }
 
 function fun2()
 {
	document.write("hi, i am fun2");
 }
 
 /* Note:
	save this file with a name "myscript.js" in current location */

//constructor for storing product details
	function Product(name, inventory, unit_price) 
	{
		this.name=name;			//init to props
		this.inventory=inventory;
		this.unit_price=unit_price;
	}
//developing functional expressions (exprfuns.js)
    
//defining a EF for finding sum of 2 numbers
const add = function(a, b){ 
							return a+b; 
						}

//defining a EF for finding power
const power = function(x,y) { 
								return x**y; 
							}
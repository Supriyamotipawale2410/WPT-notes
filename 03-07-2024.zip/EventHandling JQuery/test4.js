$('input').keypress(function(event){
    if(event.which == 88 || event.which == 120){
    alert('Hello you are pressing x or X, You are under monitoring!!!')
    }
    })

    
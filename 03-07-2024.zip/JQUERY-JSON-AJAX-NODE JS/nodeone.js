/*var fs1= require("fs");
fs1.readFile('myfile.txt',(error,data)=>{
  if(error)
console.log(error);
  else
  console.log(data);  
  console.log(data.toString()); 
    
    
});*/
/*var fs1= require("fs");
fs1.writeFile('myfile.txt','tom i will start R',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file");  
  
    
});*/

/*var fs1= require("fs");
fs1.appendFile('myfile.txt','new data',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file");  
  
    
});*/

//readFile(),writeFile() appendFile() are all asynchronous function

/*var fs1= require("fs");
console.log("started")
fs1.appendFile('myfile.txt','new data',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file"); 

  
    
});
console.log("ended") 

*/



/*var fs1= require("fs");
console.log("started")
fs1.appendFile('myfile1.txt','new data',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file"); 

  
    
});
console.log("ended")*/



/*var fs1= require("fs");
fs1.open('myfile2.txt','w',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file"); 

  
    
});
*/


/*var fs1= require("fs");
fs1.unlink('myfile2.txt',(error)=>{
  if(error)
console.log(error);
  else
  console.log("data save into file"); 

  
    
});
*/

/*var fs1= require("fs");
const fs2=fs1.readFileSync('myfile.txt')
console.log(fs2);
  console.log(fs2.toString()); */


/*var fs1= require("fs");
console.log("before")
const fs2=fs1.readFileSync('myfile2.txt')
  console.log(fs2.toString()); 
  console.log("aftern")
*/


/*var http=require("http")
var server=http.createServer();
server.listen(5030);//server starts ,the server object listens on port 8080 
console.log('server listening : http://127.0.0.1:5030'); 

*/

/*
var http=require("http")
var server=http.createServer(function(req,res){
    console.log(res.statusCode);
res.setHeader('Content-Type','text/html');
res.end("<h2>welcome to nede js </h2>");
});
server.listen(8080);//server starts 
console.log('server listening : http://127.0.0.1:5080');
*/



var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
  fs.readFile('myfile1.txt', function(err, data) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    return res.end();
  });
}).listen(5050);

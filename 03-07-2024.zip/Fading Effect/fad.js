$('button').on('click',function(){
    // $('div').fadeToggle(2000);
    $('div').fadeOut(1000);
    // $('div').fadeIn(5000);
     })


     //fadeIn()
     //fadeOut()
/*$('h1').click(function(){
    alert('h1 tag got clicked')
    })*/


 /*$('h1').click(function(){
   $(this).hide();
    }) */

   $('h1').dblclick(function(){
    $(this).hide();
     })